from typing import Any
from django.views.generic import TemplateView
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render
# Create your views here.
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect
import time
from django.contrib.auth.mixins import LoginRequiredMixin
from .forms import CreateForm, CartDetailForm
from .models import ItemTable, CartDetailTable, CartTable

class CreateUser(TemplateView):
    template_name = 'main/createUser.html'

    def __init__(self):
        self.params = {
            'title' : 'ごますけ商店',
            'status' : False,
            'form' : '',
            'message' : '',
            'icon' : '',
            'st_title' : '',
        }
    
    def get(self, request):
        form = CreateForm(label_suffix="")
        self.params['form'] = form
        self.params['status'] = False
        self.params['title'] = 'ごますけ商店'
        self.params['st_title'] = '新規登録'
        if request.user.id is None:
            return render(request, self.template_name, context=self.params)
        else:
            return redirect('main:index')
    
    def post(self, request):
        form = CreateForm(label_suffix="", data=request.POST)
        self.params['form'] = form
        if self.params['form'].is_valid():
            account = self.params['form'].save()
            account.set_password(account.password)
            if 'icon' in request.FILES:
                account.icon = request.FILES['icon']
            else:
                account.icon = 'media/main/default_icon.png'
            account.save()
            self.params["status"] = True
            self.params['st_title'] = '登録完了'
            return render(request,"main/complete.html",context=self.params)
        else:
            self.params['form'] = form
            return render(request,"main/createUser.html",context=self.params)

def index(request):
    params = {
        'user':0,
        'st_title':'TOP'
    }
    if request.user.id is not None:
        params['user'] = 1
    return render(request, 'main/index.html', params)


class Login(TemplateView):
    params = {
        'status':0,
        'st_title':'ログイン'
    }
    def get(self, request):
        if request.user.id is None:
            return render(
                request,
                'main/login.html',
                self.params,
            )
        else:
            return redirect('main:index')

    def post(self, request):
        userid = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=userid, password=password)
        if user is not None:
            login(request, user)
            self.params['username'] = userid
            return render(request, 'main/login_success.html', self.params)
        else:
            self.params['status'] = 1
            return render(request, 'main/login.html', self.params)

class ItemPage(TemplateView):
    template_name = 'main/itempage.html'
    item = ItemTable.objects.all()
    params = {
        'title':'ChirpCakes',
        'item':item,
        'st_title':'商品'
    }
    def get(self, request):
        return render(request, self.template_name, context=self.params)

class ItemDetail(TemplateView):
    template_name = 'main/product.html'
    params = {
        'st_title': '',
        'form':CartDetailForm
    }
    def get(self, request, *args, **kwargs):
        item_slug = self.kwargs['slug']
        self.params['item'] = ItemTable.objects.get(slug=item_slug)
        self.params['st_title'] = ItemTable.objects.get(slug=item_slug).item_name
        return render(request, self.template_name, self.params)


from django.core.exceptions import ObjectDoesNotExist

class Order(LoginRequiredMixin, TemplateView):
    template_name = 'main/order.html'
    params = {
        'title' : 'ChirpCakes',
        'status':0,
        'data':'',
        'st_title':'カート'
    }

    def get(self, request, *args, **kwargs):
        try:
            order = CartTable.objects.get(user_id=request.user, ordered=False)
            detail = CartDetailTable.objects.filter(cart_id=order).all()
            self.params['data'] = detail
            self.params['status'] = 1
            return render(request, self.template_name, context=self.params)
        except ObjectDoesNotExist:
            return render(request, self.template_name, context=self.params)
        
    def post(self, request, *args, **kwargs):
        item = request.POST['item_id']
        quantity = request.POST['quantity']
        # カート追加処理2回目以降
        if CartTable.objects.get(user_id=request.user, ordered=False):
            order = CartTable.objects.get(user_id=request.user, ordered=False)
            cart_id = order.cart_id
            # 既に同じ商品がカートにあった場合
            if CartDetailTable.objects.get(cart_id=cart_id, item_id=item):
                detail = CartDetailTable.objects.get(cart_id=cart_id, item_id=item)
                detail.quantity = quantity
                detail.save()
            # なかった時
            else:
                CartDetailTable.objects.create(cart_id=cart_id, item_id=item, quantity=quantity)
        # カート追加処理、初回
        else:
            CartTable.objects.create(user_id=request.user)
            order = CartTable.objects.get(user_id=request.user, ordered=False)
            cart_id = order.cart_id
            CartDetailTable.objects.create(cart_id=cart_id, item_id=item, quantity=quantity)

        order = CartTable.objects.get(user_id=request.user, ordered=False)
        detail = CartDetailTable.objects.filter(cart_id=order).all()
        self.params['data'] = detail
        self.params['status'] = 1
        return render(request, self.template_name, context=self.params)



